"""Cross-platform launcher (macOS / Linux / Windows with your own Python 3.10+).

    python run.py            -> installs requirements on first run, starts the app, opens the browser
Needs ffmpeg on PATH. Recommended: Deno or Node (YouTube downloads sometimes need a JS runtime).
"""
import os, subprocess, sys, threading, time, urllib.request, webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__)); os.chdir(ROOT)
MARK = os.path.join(ROOT, ".deps_ok")
if not os.path.exists(MARK):
    print("Installing requirements (one time)...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
    open(MARK, "w").write("ok")

URL = "http://127.0.0.1:8000"
def opener():
    for _ in range(600):
        try:
            urllib.request.urlopen(URL + "/health", timeout=3); webbrowser.open(URL); return
        except Exception: time.sleep(1)
threading.Thread(target=opener, daemon=True).start()
subprocess.call([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000"])
