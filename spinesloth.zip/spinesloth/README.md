# SpineSloth

One local app (no API keys) that finds the best moments in a video and turns them into captioned vertical shorts.

## What's inside
- **Create** - paste a link or upload a file: Whisper transcribes locally, the best moments are picked, then each clip is reframed (9:16 or square), captioned (19+ styles, fonts, karaoke/word-pop/highlight), optionally given cinematic effects, background music with voice-ducking and a signature.
- **Moment Finder** - ranks the best moments of a YouTube video from the Most Replayed graph, live-chat bursts, timestamp comments, excited speech and audio loudness; instant previews; direct stream cuts; MP4/MOV/MP3/M4A; batch download; transcript search.
- **Moment Finder -> Captioned short** - downloads ONLY the chosen ranges (not the whole video), transcribes only those seconds and renders captioned shorts.
- **Library** - every clip, with preview, reveal-in-folder and delete.

## New in this version
- Fixed "no captions" and "no sound": downloads are now verified to contain audio; split video/audio files are merged automatically; a source without sound fails with a clear message instead of silently producing a mute clip; Whisper runs on a clean 16 kHz audio track and retries without VAD if it hears nothing.
- Audio loudness-normalised to -14 LUFS (Shorts/Reels/TikTok standard).
- Every clip also gets an `.srt` subtitle file, a cover image and suggested hashtags.
- Whisper loads in the background so the app opens instantly.

## Run
- **Windows:** double-click `SpineSloth.bat` (first run installs Python, libraries and ffmpeg into this folder).
- **Mac / Linux:** `python run.py` (needs ffmpeg on PATH).
- Open http://127.0.0.1:8000

## Tips
- Sign-in / age-gated videos: set `SPINESLOTH_COOKIES_BROWSER=chrome` (or `SPINESLOTH_COOKIES_FILE=cookies.txt`).
- Keep yt-dlp current: `pip install -U yt-dlp`. Install Deno or Node if YouTube misses formats.
