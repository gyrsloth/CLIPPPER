@echo off
REM SpineSloth - double-click. First run installs Python, libraries, ffmpeg locally in this folder.
setlocal
cd /d "%~dp0"
echo.
echo   Starting SpineSloth... (first-time setup takes a while)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0packaging\run.ps1"
echo.
echo   SpineSloth has stopped. You can close this window.
pause >nul
