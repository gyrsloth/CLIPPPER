"""Per-clip extras: SRT subtitles, cover image, hashtags (all local, ffmpeg only)."""
from __future__ import annotations

import logging
import re
import subprocess
from collections import Counter
from pathlib import Path
from typing import List

logger = logging.getLogger(__name__)
_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_STOP = set("""the a an and or but if to of in on at for with is are was were be been it this that you he she we they me my your our their so just like yeah
okay uh um oh not no yes do did does have has had what when where how why can could will would there here then than from as by up out about really very get got
go going know dont its im thats gonna think thing right well want come look something because one two let also still even much need make made take back over
into only more some them these those which while after before again never always every""".split())


def _ts(t: float) -> str:
    t = max(0.0, t); h, r = divmod(int(t), 3600); m, s = divmod(r, 60)
    return f"{h:02d}:{m:02d}:{s:02d},{int(round((t - int(t)) * 1000)):03d}".replace(",1000", ",999")


def write_srt(words: List[dict], clip_start: float, clip_end: float, out: Path) -> bool:
    """Group words into readable cues (<= 7 words / 2.8 s / sentence end). Times relative to the clip."""
    cues, cur = [], []
    for w in words:
        if w["end"] <= clip_start or w["start"] >= clip_end:
            continue
        if cur and (len(cur) >= 7 or w["end"] - cur[0]["start"] > 2.8 or w["start"] - cur[-1]["end"] > 0.8):
            cues.append(cur); cur = []
        cur.append(w)
        if re.search(r"[.!?…।]$", w["word"]):
            cues.append(cur); cur = []
    if cur:
        cues.append(cur)
    if not cues:
        return False
    lines = []
    for i, c in enumerate(cues, 1):
        a, b = max(0.0, c[0]["start"] - clip_start), min(clip_end - clip_start, c[-1]["end"] - clip_start)
        lines.append(f"{i}\n{_ts(a)} --> {_ts(max(b, a + 0.3))}\n{' '.join(x['word'] for x in c)}\n")
    out.write_text("\n".join(lines), encoding="utf-8")
    return True


def make_cover(video: Path, out: Path, at: float) -> bool:
    """Grab one JPEG frame (thumbnail / cover) from the finished clip."""
    try:
        p = subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{max(0.0, at):.2f}", "-i", str(video),
                            "-frames:v", "1", "-q:v", "3", str(out)], capture_output=True, timeout=60, creationflags=_NOWIN)
        return p.returncode == 0 and out.exists()
    except Exception as exc:  # noqa: BLE001
        logger.warning("cover failed: %s", exc); return False


def hashtags(words: List[dict], title: str = "") -> List[str]:
    text = " ".join(w["word"] for w in words) + " " + title
    cnt = Counter(w for w in re.findall(r"[A-Za-z]{4,}", text.lower()) if w not in _STOP)
    return ["#" + w for w, _ in cnt.most_common(3)] + ["#shorts"]
