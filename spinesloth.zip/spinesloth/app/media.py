"""Media sanity helpers: probe streams, repair half-downloaded videos, extract audio.

Why this exists: yt-dlp downloads video and audio as SEPARATE streams and merges them with
ffmpeg. When the merge doesn't happen (ffmpeg not found by yt-dlp, odd codecs, interrupted
run) the folder is left with e.g. ``<id>.f137.mp4`` (video only) and ``<id>.f140.m4a`` (audio
only). Picking "the first file" then gives a silent video, Whisper hears nothing and no
captions appear. Everything here makes that situation detectable and fixable.
"""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)
_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
JUNK = (".part", ".ytdl", ".temp", ".tmp", ".json", ".ass", ".wav")


def ffmpeg_path() -> Optional[str]:
    return shutil.which("ffmpeg")


def probe(path) -> dict:
    """Return {has_video, has_audio, duration, vcodec, acodec}. Never raises."""
    out = dict(has_video=False, has_audio=False, duration=0.0, vcodec="", acodec="")
    try:
        p = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,codec_name:format=duration",
             "-of", "json", str(path)],
            capture_output=True, text=True, timeout=60, creationflags=_NOWIN)
        d = json.loads(p.stdout or "{}")
        for s in d.get("streams", []):
            if s.get("codec_type") == "video" and s.get("codec_name") not in ("mjpeg", "png"):
                out["has_video"], out["vcodec"] = True, s.get("codec_name", "")
            elif s.get("codec_type") == "audio":
                out["has_audio"], out["acodec"] = True, s.get("codec_name", "")
        out["duration"] = float((d.get("format") or {}).get("duration") or 0)
    except Exception as exc:  # noqa: BLE001
        logger.warning("ffprobe failed for %s: %s", path, exc)
    return out


def _run(cmd: list[str], timeout: int = 3600) -> None:
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       timeout=timeout, creationflags=_NOWIN)
    if p.returncode:
        raise RuntimeError("\n".join((p.stderr or "").strip().splitlines()[-4:]) or "ffmpeg failed")


def repair_download(folder: Path, stem: str) -> Optional[Path]:
    """Given every file yt-dlp left as ``<stem>.*``, return ONE playable mp4 with video + audio.

    Strategy: (1) a single file that already has both streams wins; (2) otherwise mux the best
    video-only file with the best audio-only file into ``<stem>.mp4``. Returns None if impossible.
    """
    files = [f for f in sorted(folder.glob(f"{stem}*")) if f.is_file() and f.suffix.lower() not in JUNK]
    info = {f: probe(f) for f in files}
    both = [f for f in files if info[f]["has_video"] and info[f]["has_audio"]]
    if both:
        return max(both, key=lambda f: f.stat().st_size)
    vids = [f for f in files if info[f]["has_video"]]
    auds = [f for f in files if info[f]["has_audio"] and not info[f]["has_video"]]
    if vids and auds and ffmpeg_path():
        v, a = max(vids, key=lambda f: f.stat().st_size), max(auds, key=lambda f: f.stat().st_size)
        dest = folder / f"{stem}.merged.mp4"
        try:
            _run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(v), "-i", str(a),
                  "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                  "-movflags", "+faststart", str(dest)])
            final = folder / f"{stem}.mp4"
            if final.exists() and final != v:
                final.unlink()
            dest.replace(final) if final != v else None
            if final == v:  # video-only file was named <stem>.mp4 -> keep merged next to it
                return dest
            for f in (v, a):
                if f != final:
                    f.unlink(missing_ok=True)
            return final
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not merge %s + %s: %s", v.name, a.name, exc)
    return vids[0] if vids else None


def extract_audio_wav(src, dst) -> Path:
    """16 kHz mono WAV of the first audio stream - what Whisper wants, and a hard check that audio exists."""
    dst = Path(dst)
    _run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(src), "-map", "0:a:0",
          "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(dst)], timeout=1800)
    return dst
