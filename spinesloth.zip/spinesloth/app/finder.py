"""Moment Finder engine (ported from Clip Finder Pro / beta5).

Finds the best moments in a YouTube video by combining independent signals:
  Most Replayed heatmap + live-chat bursts + timestamp comments + transcript excitement
  + audio loudness, with a cross-signal agreement bonus and sentence-snapped cuts.

It also owns the fast paths: 360p local previews and direct stream cuts (no full download),
GPU encoder auto-detect, 9:16 fill / fit+blur reframing, and MP3/M4A/MOV export.

Pure Python + ffmpeg + yt-dlp. No web framework here - see app/finder_api.py for the routes.
"""
from __future__ import annotations

import os, re, sys, json, glob, uuid, shutil, subprocess, threading, time, bisect
from collections import Counter, defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
import urllib.parse
from pathlib import Path
from . import history, media
from .paths import CACHE_DIR, CLIPS_DIR, EXPORTS_DIR

CACHE = str(CACHE_DIR)
OUT = os.path.join(CACHE, "out")  # scratch dir for finished renders until they are filed
os.makedirs(CACHE, exist_ok=True); os.makedirs(OUT, exist_ok=True)
JOBS, SIG, PREV, RES, KLOCKS = {}, {}, {}, {}, {}
PREVPOOL, PRIOPOOL = ThreadPoolExecutor(3), ThreadPoolExecutor(3)
RSEM, LOCK = threading.Semaphore(2), threading.Lock()
PAD = 10  # seconds of extra video around local previews
QS = ("2160", "1440", "1080", "720", "480", "360")
EXTS = ("mp4", "mov", "mp3", "m4a")
PV_SEL = "bv*[height<=360][vcodec^=avc1]+ba[ext=m4a]/bv*[height<=480]+ba/b[height<=480]/w"

HYPE = re.compile(r"(lol|lmao|omg|wtf|bruh|haha|😂|🤣|😭|💀|🔥|😱|insane|crazy|clip|\bW+\b|lets go|let's go|pog+|no way|clutch|goat|sheesh|holy|nooo+|!{3,})", re.I)
LAUGH = re.compile(r"(lol|lmao|lmfao|haha|😂|🤣|😭|💀|rofl)", re.I)
SHOCK = re.compile(r"(omg|wtf|no way|holy|😱|nooo+|bruh|what the)", re.I)
HYPEW = re.compile(r"(pog+|let'?s go|lets go|clutch|goat|sheesh|🔥|\bw+\b|insane|crazy|clip)", re.I)
EXC = re.compile(r"(oh my god|no way|let'?s go|holy|what the|are you kidding|insane|crazy|unbelievable|i can'?t|oh no|clutch|\bgg\b|\[laughter\]|\[applause\]|\[cheering\])", re.I)
TS = re.compile(r"(?<![\d:])(?:(\d{1,2}):)?(\d{1,2}):(\d{2})(?![\d:])")
OFF = re.compile(rb'"videoOffsetTimeMsec"\s*:\s*"?(-?\d+)')
SPEED = {"fast": ("veryfast", 21), "balanced": ("fast", 18), "best": ("medium", 15)}
STOP = set("""the a an and or but if to of in on at for with is are was were be been it this that you he she we they me my your our their so just like yeah
okay uh um oh not no yes do did does have has had what when where how why can could will would there here then than from as by up out about really very get got
go going know dont its im thats gonna think thing right well want come look something because they're i'm it's don't that's one two let also still even much
need make made take back over into only more some been them these those which while after before again never always every""".split())

HW = {
    "h264_nvenc": ["-c:v", "h264_nvenc", "-preset", "p4", "-cq", "23", "-b:v", "0"],
    "h264_qsv": ["-c:v", "h264_qsv", "-global_quality", "23"],
    "h264_amf": ["-c:v", "h264_amf", "-quality", "speed", "-rc", "cqp", "-qp_i", "22", "-qp_p", "24"],
    "h264_videotoolbox": ["-c:v", "h264_videotoolbox", "-q:v", "60"],
}
_ENC = None


def run(cmd, timeout=None):
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
    if p.returncode:
        lines = [l for l in (p.stderr or p.stdout).strip().splitlines() if l.strip()]
        raise RuntimeError(" | ".join(lines[-2:])[:400] or "Unknown error")
    return p.stdout


def video_id(url):
    m = re.search(r"(?:v=|youtu\.be/|/live/|/shorts/)([A-Za-z0-9_-]{11})", url or "")
    return m.group(1) if m else None


def rm(pattern):
    for f in glob.glob(pattern):
        try: os.remove(f)
        except OSError: pass


def lock_for(key):
    with LOCK: return KLOCKS.setdefault(key, threading.Lock())


def ft(t):
    t = int(t); h, m = t // 3600, t % 3600 // 60
    return (f"{h}:{m:02d}" if h else str(m)) + f":{t % 60:02d}"


def encoder():
    """Detect a working GPU H.264 encoder once. Returns ffmpeg args or []."""
    global _ENC
    with lock_for("enc"):
        if _ENC is not None: return _ENC
        _ENC = []
        try: have = run(["ffmpeg", "-hide_banner", "-encoders"])
        except Exception: return _ENC
        for name, args in HW.items():
            if name not in have: continue
            try:
                run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=black:s=640x360:d=0.2",
                     "-pix_fmt", "yuv420p"] + args + ["-f", "null", "-"], timeout=25)
                _ENC = args; break
            except Exception: pass
        return _ENC


def venc(speed):
    preset, crf = SPEED.get(speed, SPEED["fast"])
    hw = encoder()
    if hw and speed != "best": return hw
    return ["-c:v", "libx264", "-preset", preset, "-crf", str(crf)]


# ---------- signal cache (re-ranking with another length is instant) ----------
def sig_file(vid): return os.path.join(CACHE, vid + ".sig.json")


def new_sig(vid, title, dur):
    nb = dur // 5 + 1
    return dict(vid=vid, title=title, duration=dur, heat=[0.0] * nb, msgs=[0] * nb, hype=[0] * nb, cmt=[0] * nb, tx=[0] * nb,
                talk=[0] * nb, aud=[0.0] * nb, words={}, segs=[], chat_done=False, cmt_done=False, tx_done=False, aud_done=False)


def fix_sig(s):
    nb = len(s["heat"])
    for k in ("msgs", "hype", "cmt", "tx", "talk"): s.setdefault(k, [0] * nb)
    s.setdefault("aud", [0.0] * nb); s.setdefault("segs", []); s.setdefault("words", {})
    for k in ("tx_done", "aud_done"): s.setdefault(k, False)
    return s


def load_sig(vid):
    if vid in SIG: return SIG[vid]
    try:
        with open(sig_file(vid), encoding="utf-8") as f: SIG[vid] = fix_sig(json.load(f))
        return SIG[vid]
    except Exception:
        return None


def save_sig(s):
    try:
        with LOCK, open(sig_file(s["vid"]), "w", encoding="utf-8") as f: json.dump(s, f)
    except OSError: pass


def has_signal(s): return any(sum(s[k]) > 0 for k in ("heat", "msgs", "hype", "cmt", "tx", "aud"))


def tail_offset(path):
    try:
        with open(path, "rb") as f:
            f.seek(0, 2); f.seek(max(0, f.tell() - 200000)); m = OFF.findall(f.read())
        return int(m[-1]) / 1000 if m else 0
    except Exception: return 0


def fetch_chat(url, vid, s, j):
    prefix, dur = os.path.join(CACHE, vid), max(1, s["duration"])
    files = glob.glob(prefix + "*.live_chat.json")
    if not files:
        p = subprocess.Popen(Y() + ["--skip-download", "--write-subs", "--sub-langs", "live_chat", "--no-playlist", "--no-warnings",
                                      "--retries", "10", "--fragment-retries", "10", "-o", prefix, url],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        while p.poll() is None:  # real progress = how far into the stream the chat file has got
            part = glob.glob(prefix + "*.live_chat.json.part")
            if part: j["chat"] = min(.97, tail_offset(part[0]) / dur)
            time.sleep(1)
        files = glob.glob(prefix + "*.live_chat.json")
        if not files:
            if p.returncode: raise RuntimeError("chat download failed")
            return False
    nb, words = len(s["msgs"]), defaultdict(Counter)
    with open(files[0], encoding="utf-8") as f:
        for line in f:
            try:
                a = json.loads(line)["replayChatItemAction"]; t = int(a.get("videoOffsetTimeMsec", -1)) / 1000
            except Exception: continue
            b = int(t // 5)
            if t < 0 or b >= nb: continue
            for act in a.get("actions", []):
                item = act.get("addChatItemAction", {}).get("item", {})
                paid = item.get("liveChatPaidMessageRenderer") or item.get("liveChatPaidStickerRenderer")
                r = item.get("liveChatTextMessageRenderer") or paid
                if not r: continue
                s["msgs"][b] += 1
                text = "".join(x.get("text") or x.get("emoji", {}).get("emojiId", "") for x in r.get("message", {}).get("runs", []))
                found = HYPE.findall(text)
                if found:
                    s["hype"][b] += 1
                    for w in found: words[b][w.lower()] += 1
                if paid: s["hype"][b] += 3
    s["words"] = {str(b): dict(c.most_common(3)) for b, c in words.items()}
    return True


def fetch_comments(url, s):
    out = run(Y() + ["-J", "--no-warnings", "--no-playlist", "--write-comments", "--extractor-args",
                       "youtube:max_comments=250,all,0,0;comment_sort=top", url], timeout=240)
    for cm in json.loads(out).get("comments") or []:
        for h, m, sec in TS.findall(cm.get("text", "")):
            t = int(h or 0) * 3600 + int(m) * 60 + int(sec)
            if 0 < t < s["duration"]: s["cmt"][t // 5] += 1 + min(cm.get("like_count") or 0, 50) // 10


def fetch_subs(url, vid, s):
    """Captions -> speech excitement per 5s bucket + searchable transcript."""
    prefix = os.path.join(CACHE, vid)
    files = glob.glob(prefix + "*.json3")
    if not files:
        try:
            subprocess.run(Y() + ["--skip-download", "--write-subs", "--write-auto-subs", "--sub-langs", "en.*,en,.*-orig", "--sub-format", "json3",
                                    "--no-playlist", "--no-warnings", "--retries", "5", "-o", prefix, url],
                           capture_output=True, timeout=300)
        except Exception: pass
        files = glob.glob(prefix + "*.json3")
    if not files: return False
    files.sort(key=lambda f: ("-orig" not in f, "en" not in os.path.basename(f)))
    with open(files[0], encoding="utf-8") as f: data = json.load(f)
    nb, segs = len(s["tx"]), []
    s["tx"], s["talk"] = [0] * nb, [0] * nb
    for ev in data.get("events", []):
        if "segs" not in ev: continue
        t, d = ev.get("tStartMs", 0) / 1000, ev.get("dDurationMs", 0) / 1000
        text = "".join(x.get("utf8", "") for x in ev["segs"]).replace("\n", " ").strip()
        if not text: continue
        segs.append([round(t, 1), round(t + d, 1), text])
        b = int(t // 5)
        if b >= nb: continue
        s["talk"][b] += len(text.split())
        s["tx"][b] += len(EXC.findall(text)) + text.count("!") + 2 * len(re.findall(r"\[(?:laughter|applause|cheering)\]", text, re.I))
    segs.sort()
    s["segs"] = segs
    return bool(segs)


def fetch_audio(url, vid, s, j):
    """Low-quality audio of the whole video -> loudness (dB above floor) per 5s bucket."""
    prefix = os.path.join(CACHE, vid + ".aud")
    rm(prefix + "*")
    run(Y() + ["--no-playlist", "--no-warnings", "-f", "wa[ext=m4a]/wa/worst", "--retries", "10", "--fragment-retries", "10",
                 "--concurrent-fragments", "8", "-o", prefix + ".%(ext)s", url], timeout=3600)
    f = [x for x in glob.glob(prefix + ".*") if not x.endswith((".part", ".ytdl"))]
    if not f: raise RuntimeError("audio download failed")
    nb, i = len(s["aud"]), 0
    p = subprocess.Popen(["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-i", f[0], "-vn", "-af",
                          "aresample=8000,asetnsamples=n=40000,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-",
                          "-f", "null", "-"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace")
    for line in p.stdout:
        m = re.search(r"RMS_level=(-?[\d.]+|-inf)", line)
        if not m: continue
        v = m.group(1)
        if i < nb: s["aud"][i] = 0.0 if v == "-inf" else round(max(0.0, float(v) + 70), 1)
        i += 1
        if i % 20 == 0: j["aud"] = min(.97, i / nb)
    p.wait(); rm(prefix + "*")
    return i > 0


def analyze_job(jid, url, opts, force):
    j = JOBS[jid]
    try:
        vid = video_id(url); url = "https://www.youtube.com/watch?v=" + vid
        if force:
            SIG.pop(vid, None); rm(os.path.join(CACHE, vid + "*"))
        s = load_sig(vid)
        if not s:
            j["msg"] = "Reading video info + Most Replayed..."
            info = json.loads(run(Y() + ["-J", "--no-warnings", "--no-playlist", url], timeout=300))
            if info.get("is_live"): raise RuntimeError("This stream is still live. Wait until it ends, then paste the replay link.")
            dur = int(info.get("duration") or 0); s = SIG[vid] = new_sig(vid, info.get("title", ""), dur)
            nb = len(s["heat"])
            for h in info.get("heatmap") or []:
                for b in range(int(h["start_time"] // 5), min(nb, int(h["end_time"] // 5) + 1)): s["heat"][b] = h["value"]
            save_sig(s)
        st = lambda use, done: -1 if not use else (1 if done else 0)
        j.update(vid=vid, title=s["title"], duration=s["duration"], info=True, ready=has_signal(s), rev=1,
                 chat=st(opts["chat"], s["chat_done"]), cmt=st(opts["cmt"], s["cmt_done"]), tx=st(opts["tx"], s["tx_done"]), aud=st(opts["aud"], s["aud_done"]),
                 msg="Top moments shown. Refining with chat, comments, transcript and audio...")
        threading.Thread(target=lambda: resolve(vid, PV_SEL), daemon=True).start()  # pre-warm stream URLs for fast previews

        def bump():
            save_sig(s); j["ready"] = has_signal(s); j["rev"] += 1

        def mk(name, use, flag, fn):
            def t():
                if not use or s[flag]: return
                try:
                    ok = fn(); s[flag] = True; j[name] = -3 if ok is False else 1
                except Exception: j[name] = -2
                bump()
            return t

        fns = [mk("chat", opts["chat"], "chat_done", lambda: fetch_chat(url, vid, s, j)),
               mk("cmt", opts["cmt"], "cmt_done", lambda: fetch_comments(url, s)),
               mk("tx", opts["tx"], "tx_done", lambda: fetch_subs(url, vid, s)),
               mk("aud", opts["aud"], "aud_done", lambda: fetch_audio(url, vid, s, j))]
        ts = [threading.Thread(target=f, daemon=True) for f in fns]
        [t.start() for t in ts]; [t.join() for t in ts]
        if not has_signal(s): raise RuntimeError("No Most Replayed data, chat replay, transcript, audio or timestamp comments found for this video.")
        j.update(msg="Done", done=True)
    except Exception as e:
        j["err"] = str(e)


# ---------- ranking ----------
W = {"heat": .30, "chat": .30, "aud": .15, "tx": .15, "cmt": .10}


def pvinfo(vid, ss, end, dur):
    base, stop = max(0, int(ss) - PAD), int(end) + PAD + 1
    if dur: stop = min(stop, dur)
    return f"p_{vid}_{base}_{stop}.mp4", base, stop


def prefix(a):
    P = [0.0]
    for v in a: P.append(P[-1] + v)
    return P


def smooth(a, r=1):
    n, P = len(a), prefix(a)
    return [(P[min(n, i + r + 1)] - P[max(0, i - r)]) / (min(n, i + r + 1) - max(0, i - r)) for i in range(n)]


def burst(a, rad=60):
    """How much each bucket rises above its own surroundings (anomaly, not absolute level)."""
    n, P = len(a), prefix(a); out = []
    for i in range(n):
        lo, hi = max(0, i - rad), min(n, i + rad + 1)
        out.append(max(0.0, a[i] - (P[hi] - P[lo]) / (hi - lo)))
    return out


def norm(a):
    if not a: return a
    m = sorted(a)[int(len(a) * .995)] or max(a) or 1
    return [min(1.0, v / m) for v in a]


def signals(s):
    nb, comp = len(s["heat"]), {}
    chat = [m + 2 * h for m, h in zip(s["msgs"], s["hype"])]
    if sum(s["heat"]) > 0: comp["heat"] = norm(smooth(s["heat"], 1))
    if sum(chat) > 0:
        sc = smooth(chat, 1); comp["chat"] = [.7 * x + .3 * y for x, y in zip(norm(burst(sc)), norm(sc))]
    if sum(s["aud"]) > 0: comp["aud"] = norm(burst(smooth(s["aud"], 1)))
    if sum(s["tx"]) > 0: comp["tx"] = norm(smooth(s["tx"], 1))
    if sum(s["cmt"]) > 0: comp["cmt"] = norm(smooth(s["cmt"], 2))
    if not comp: return {}, []
    tw, comb = sum(W[k] for k in comp), [0.0] * nb
    for k, a in comp.items():
        w = W[k] / tw
        for b in range(nb): comb[b] += w * a[b]
    if len(comp) > 1:  # several independent signals agreeing = real highlight
        for b in range(nb):
            ag = sum(1 for a in comp.values() if a[b] > .5)
            if ag > 1: comb[b] *= 1 + .15 * (ag - 1)
        mx = max(comb) or 1; comb = [c / mx for c in comb]
    return comp, comb


def snapper(segs):
    st, ens = [g[0] for g in segs], sorted(g[1] for g in segs)

    def s0(t):
        i = bisect.bisect_right(st, t + 2) - 1
        return st[i] if i >= 0 and t - st[i] <= 8 else t

    def e0(t):
        i = bisect.bisect_left(ens, t - 1)
        return ens[i] if i < len(ens) and ens[i] - t <= 8 else t
    return s0, e0


def pick_smart(sm, nb, maxlen, count):
    """AI-length clips: grow around each peak while the energy stays high."""
    maxb = max(3, round(maxlen / 5)); minb = min(maxb, 3)
    taken, out = [False] * nb, []
    for b in sorted(range(nb), key=lambda i: -sm[i]):
        if len(out) >= count or sm[b] <= .03: break
        if taken[b]: continue
        pk = sm[b]; thr = pk * .45; l = r = b
        while r - l + 1 < maxb:
            lv = sm[l - 1] if l > 0 and not taken[l - 1] else -1
            rv = sm[r + 1] if r < nb - 1 and not taken[r + 1] else -1
            if max(lv, rv) < thr: break
            if lv >= rv: l -= 1
            else: r += 1
        while r - l + 1 < minb:
            if l > 0 and not taken[l - 1]: l -= 1
            if r - l + 1 < minb and r < nb - 1 and not taken[r + 1]: r += 1
            if (l == 0 or taken[l - 1]) and (r == nb - 1 or taken[r + 1]): break
        if r - l + 1 < maxb and l > 0 and not taken[l - 1]: l -= 1
        if r - l + 1 < maxb and r < nb - 1 and not taken[r + 1]: r += 1
        for i in range(max(0, l - 1), min(nb, r + 2)): taken[i] = True
        out.append((.5 * pk + .5 * sum(sm[l:r + 1]) / (r - l + 1), l, r))
    return out


def stats(s, comp, comb):
    nb, dur = len(comb), s["duration"]; o = dict(duration=dur, signals=list(comp))
    tot = sum(s["msgs"])
    if tot:
        pm = [sum(s["msgs"][i:i + 12]) for i in range(0, nb, 12)]; k = max(range(len(pm)), key=pm.__getitem__)
        o.update(chat_total=tot, chat_avg=round(tot / max(1, dur / 60), 1), chat_peak=pm[k], chat_peak_at=k * 60, hype_pct=round(100 * sum(s["hype"]) / tot))
    wc = Counter()
    for d in s["words"].values(): wc.update(d)
    o["top_react"] = [w for w, _ in wc.most_common(8)]
    segs = s.get("segs") or []
    o["has_tx"] = bool(segs)
    if segs:
        kw = Counter(w for g in segs for w in re.findall(r"[a-zA-Z']{4,}", g[2].lower()) if w not in STOP)
        o["keywords"] = [w for w, _ in kw.most_common(12)]
        o["speech_pct"] = round(100 * sum(1 for v in s["talk"] if v > 0) / nb)
    span = min(nb, 120)
    if nb > span:
        P = prefix(comb); o["best_block"] = max(range(nb - span + 1), key=lambda i: P[i + span] - P[i]) * 5
    return o


def rank(s, length, count, mode):
    nb, dur = len(s["heat"]), s["duration"]
    comp, comb = signals(s)
    if not comp: return [], [], {}
    sm = smooth(comb, 1)
    segs = s.get("segs") or []
    s0, e0 = snapper(segs) if segs else (None, None)
    if mode == "fixed":
        span = max(1, round(length / 5)); P = prefix(comb)
        wins = sorted(((P[min(nb, x + span)] - P[x] + .5 * max(comb[x:min(nb, x + span)]), x) for x in range(max(1, nb - span))), reverse=True)
        picks = []
        for sc, x in wins:
            if all(abs(x - p[1]) >= span for p in picks): picks.append((sc, x))
            if len(picks) >= count: break
        spans = [(sc / span, x, min(nb - 1, x + span - 1)) for sc, x in picks]
    else:
        spans = pick_smart(sm, nb, length, count)
    if not spans: return [], [], {}
    best = max(x[0] for x in spans) or 1
    med = sorted(v for v in s["aud"] if v > 0); med = med[len(med) // 2] if med else 0
    gmean = sum(s["msgs"]) / nb
    out = []
    for sc, l, r in spans:
        a, b = l, min(r + 1, nb); n = max(1, b - a)
        peak = max(range(a, b), key=lambda i: comb[i])
        if mode == "fixed":
            start = max(0, min(a * 5 - 5, max(0, dur - length)))
            if s0: start = max(0, min(int(s0(start)), max(0, dur - length)))
            end = min(dur, start + length) if dur else start + length
        else:
            start, end = a * 5, min(dur, b * 5)
            if s0: start, end = int(s0(start)), int(e0(end)) + 1
            start, end = max(0, start), min(dur, end)
            if end - start > length: end = start + length
            if end - start < 10: end = min(dur, start + 10)
        score = round(100 * sc / best)
        react = Counter()
        for bb in range(a, b): react.update(s["words"].get(str(bb), {}))
        wsegs = [g for g in segs if g[1] > start and g[0] < end]
        lc = sum(c for w, c in react.items() if LAUGH.search(w)); shc = sum(c for w, c in react.items() if SHOCK.search(w)); hc = sum(c for w, c in react.items() if HYPEW.search(w))
        if any(re.search(r"\[laughter\]", g[2], re.I) for g in wsegs): lc += 3
        kinds = [("😂 Funny", lc), ("😱 Shock", shc), ("🔥 Hype", hc)]
        kind = max(kinds, key=lambda k: k[1]); kind = kind[0] if kind[1] > 0 else "⭐ Highlight"
        why = []
        if "heat" in comp:
            hv = round(100 * sum(s["heat"][a:b]) / n)
            if hv >= 50: why.append(f"Most Replayed {hv}%")
        chatn = sum(s["msgs"][a:b])
        if chatn and gmean:
            xr = chatn / n / gmean
            if xr >= 1.5: why.append(f"Chat {xr:.1f}x normal")
        if "aud" in comp and med:
            db = max(s["aud"][a:b]) - med
            if db >= 3: why.append(f"+{db:.0f} dB louder")
        cm = sum(s["cmt"][a:b])
        if cm: why.append(f"{cm} timestamp comments")
        if sum(s["tx"][a:b]) >= 2: why.append("Excited speech")
        best_seg = max(wsegs, key=lambda g: (len(EXC.findall(g[2])) + g[2].count("!"), len(g[2])), default=None)
        quote = re.sub(r"\[[^\]]*\]", "", best_seg[2]).strip()[:120] if best_seg else ""
        if len(quote) < 12: quote = ""
        words = Counter(w for g in wsegs for w in re.findall(r"[a-zA-Z']{4,}", g[2].lower()) if w not in STOP)
        tags = ["#" + w.replace("'", "") for w, _ in words.most_common(3)] + ["#" + kind.split(" ", 1)[1].lower()]
        title = ((quote[:1].upper() + quote[1:]) if quote else f"{kind.split(' ', 1)[1]} moment at {ft(start)}").strip(" -,.")[:70]
        key, pb, pe = pvinfo(s["vid"], start, end, dur)
        out.append(dict(start=start, end=end, peak=peak * 5, score=score, stars=5 if score >= 85 else 4 if score >= 65 else 3 if score >= 45 else 2 if score >= 25 else 1,
                        heat=round(100 * sum(s["heat"][a:b]) / n) if "heat" in comp else None,
                        chat=chatn if "chat" in comp else None, hype=sum(s["hype"][a:b]) if "chat" in comp else None, cmt=cm if "cmt" in comp else None,
                        react=[w for w, _ in react.most_common(3)], kind=kind, why=why, quote=quote, title=title, tags=tags,
                        pv=dict(key=key, base=pb, stop=pe)))
    return out, [round(100 * c) for c in comb], stats(s, comp, comb)


# ---------- stream resolving (done once, reused by every preview and download) ----------
def sel_for(q):
    cap = f"[height<={q}]" if q in QS else ""
    if q in ("1080", "720", "480", "360"):  # H.264 is fastest to decode, and can be stream-copied
        return f"bv*{cap}[vcodec^=avc1]+ba[ext=m4a]/bv*{cap}+ba/b{cap}/b"
    return f"bv*{cap}[vcodec!^=av01]+ba/bv*{cap}+ba/b{cap}/b"


def resolve(vid, sel):
    key = (vid, sel)
    with lock_for("res:" + vid + sel):
        e = RES.get(key)
        if e and time.time() - e[0] < 5400: return e[1]
        info = json.loads(run(Y() + ["-J", "--no-warnings", "--no-playlist", "-f", sel, "https://www.youtube.com/watch?v=" + vid], timeout=180))
        out = []
        for f in info.get("requested_formats") or [info]:
            out.append(dict(url=f["url"], h=dict(f.get("http_headers") or {}), v=f.get("vcodec") not in (None, "none"),
                            a=f.get("acodec") not in (None, "none"), vc=f.get("vcodec") or "", ac=f.get("acodec") or "", fps=f.get("fps")))
        RES[key] = (time.time(), out)
        return out


def ff_inputs(fm, ss):
    cmd = []
    for f in fm:
        ua = next((v for k, v in f["h"].items() if k.lower() == "user-agent"), None)
        h = {k: v for k, v in f["h"].items() if k.lower() not in ("accept-encoding", "range", "user-agent")}
        if ua: cmd += ["-user_agent", ua]
        if h: cmd += ["-headers", "".join(f"{k}: {v}\r\n" for k, v in h.items())]
        cmd += ["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "5", "-ss", f"{ss:.3f}", "-i", f["url"]]
    return cmd


def ff_maps(fm, audio_only=False):
    vi = [i for i, f in enumerate(fm) if f["v"]]; ai = [i for i, f in enumerate(fm) if f["a"]]; m = []
    if vi and not audio_only: m += ["-map", f"{vi[0]}:v:0"]
    if ai: m += ["-map", f"{ai[-1]}:a:0"]
    return m


# ---------- previews ----------
def make_preview(vid, key, base, stop):
    out, tmp = os.path.join(CACHE, key), os.path.join(CACHE, "t_" + key[:-4])
    with lock_for("pv:" + key):
        if os.path.exists(out): PREV[key] = "ok"; return
        PREV[key] = "run"
        try:
            try:  # fast path: ffmpeg straight from the resolved stream, ultrafast 360p
                fm = resolve(vid, PV_SEL)
                part = out + ".part.mp4"
                run(["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y"] + ff_inputs(fm, base) + ff_maps(fm) +
                    ["-t", str(stop - base), "-vf", "scale=-2:'min(360,ih)'", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "30", "-pix_fmt", "yuv420p",
                     "-g", "30", "-c:a", "aac", "-b:a", "80k", "-movflags", "+faststart", part], timeout=240)
                os.replace(part, out)
            except Exception:  # fallback: classic yt-dlp section download
                RES.pop((vid, PV_SEL), None); rm(out + ".part.mp4")
                run(Y() + ["--no-playlist", "--download-sections", f"*{base}-{stop}", "--force-keyframes-at-cuts", "-f",
                             "bv*[height<=360][ext=mp4]+ba[ext=m4a]/b[height<=360][ext=mp4]/b[height<=480]/w", "--merge-output-format", "mp4",
                             "--retries", "5", "--socket-timeout", "30", "--concurrent-fragments", "4", "-o", tmp + ".%(ext)s",
                             "https://www.youtube.com/watch?v=" + vid], timeout=400)
                f = [x for x in glob.glob(tmp + ".*") if x.endswith(".mp4")]
                os.replace(f[0], out)
            PREV[key] = "ok"
        except Exception:
            PREV[key] = "fail"
        finally:
            rm(tmp + "*")


# ---------- downloads ----------
def build_vf(fmt, mode, pan, q):
    W_ = int(q) if q in QS else 1080; H = W_ * 16 // 9 // 2 * 2
    if fmt == "vertical" and mode == "fill": return f"crop=w=ih*9/16:h=ih:x=(in_w-out_w)*{pan}:y=0,scale={W_}:{H}"
    if fmt == "vertical": return f"split[a][b];[a]scale={W_}:{H}:force_original_aspect_ratio=increase,crop={W_}:{H},boxblur=25[bg];[b]scale={W_}:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2"
    return "scale=trunc(iw/2)*2:trunc(ih/2)*2"


def ffrun(cmd, total, j):
    cmd = cmd[:1] + ["-progress", "pipe:1", "-nostats"] + cmd[1:]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    tail = deque(maxlen=4)
    for line in p.stdout:
        if line.startswith("out_time_us="):
            try: j["pct"] = min(.99, int(line.split("=")[1]) / 1e6 / max(total, 1))
            except ValueError: pass
        elif "=" not in line: tail.append(line.strip())
    if p.wait(): raise RuntimeError("ffmpeg failed: " + " | ".join(tail)[:300])


def outname(cname, default, ext):
    """User-chosen file name (sanitised) + extension; never overwrites an existing clip."""
    base = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", cname or "").strip(" .")[:120] or default
    n, i = base + ext, 1
    while os.path.exists(os.path.join(OUT, n)):
        i += 1; n = f"{base} ({i}){ext}"
    return n


def audio_args(ext):
    return ["-c:a", "libmp3lame", "-b:a", "192k"] if ext == "mp3" else ["-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart"]


def render_fast(j, vid, ss, end, fmt, mode, pan, q, speed, audio, ext="mp4", cname=""):
    dur = end - ss
    copy = speed == "copy" and fmt == "horizontal" and not audio
    j["msg"] = "Finding stream..."
    fm = resolve(vid, "ba[ext=m4a]/ba" if audio else sel_for(q))
    head = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y"] + ff_inputs(fm, ss)
    if audio:
        name = outname(cname, f"{vid}_audio_{int(ss)}-{int(end)}", "." + ext); j["msg"] = "Cutting audio..."
        ffrun(head + ff_maps(fm, True) + ["-t", f"{dur:.3f}", "-vn"] + audio_args(ext) + [os.path.join(OUT, name)], dur, j)
        return name
    name = outname(cname, f"{vid}_{fmt}_{q}_{int(ss)}-{int(end)}", "." + ext); path = os.path.join(OUT, name)
    v = next(f for f in fm if f["v"]); a = [f for f in fm if f["a"]]
    if copy and v["vc"].startswith("avc1") and a and a[-1]["ac"].startswith("mp4a"):
        j["msg"] = "Cutting (instant copy)..."
        ffrun(head + ff_maps(fm) + ["-t", f"{dur:.3f}", "-c", "copy", "-avoid_negative_ts", "make_zero", "-movflags", "+faststart", path], dur, j)
    else:
        j["msg"] = "Encoding clip..."
        ffrun(head + ff_maps(fm) + ["-t", f"{dur:.3f}", "-vf", build_vf(fmt, mode, pan, q)] + venc("fast" if speed == "copy" else speed) +
              ["-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", path], dur, j)
    return name


def render_slow(j, vid, ss, end, fmt, mode, pan, q, speed, audio, ext="mp4", cname=""):
    """Fallback: classic yt-dlp section download + ffmpeg."""
    url = "https://www.youtube.com/watch?v=" + vid
    base = os.path.join(CACHE, f"{vid}_{int(ss * 1000)}_{int(end * 1000)}_raw")
    try:
        rm(base + "*")
        for attempt in range(3):
            j["msg"] = "Downloading exact range..." if attempt == 0 else f"Retrying download ({attempt + 1}/3)..."
            try:
                run(Y() + ["--no-playlist", "--download-sections", f"*{ss:.2f}-{end:.2f}", "--force-keyframes-at-cuts", "-f", "ba" if audio else sel_for(q),
                             "--merge-output-format", "mkv", "--retries", "10", "--fragment-retries", "10", "--concurrent-fragments", "8",
                             "--socket-timeout", "30", "-o", base + ".%(ext)s", url], timeout=3600)
                break
            except Exception:
                if attempt == 2: raise
                time.sleep(2)
        raw = [f for f in glob.glob(base + "*") if not f.endswith((".part", ".ytdl"))]
        if not raw: raise RuntimeError("Download produced no file. Update yt-dlp: pip install -U yt-dlp")
        if audio:
            name = outname(cname, f"{vid}_audio_{int(ss)}-{int(end)}", "." + ext); j["msg"] = "Converting audio..."
            ffrun(["ffmpeg", "-y", "-i", raw[0], "-vn"] + audio_args(ext) + [os.path.join(OUT, name)], end - ss, j)
        else:
            name = outname(cname, f"{vid}_{fmt}_{q}_{int(ss)}-{int(end)}", "." + ext); j["msg"] = "Encoding final clip..."
            ffrun(["ffmpeg", "-y", "-i", raw[0], "-vf", build_vf(fmt, mode, pan, q)] + venc("fast" if speed == "copy" else speed) +
                  ["-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", os.path.join(OUT, name)], end - ss, j)
        return name
    finally:
        rm(base + "*")


def render_job(jid, url, ss, end, fmt, mode, pan, q, speed, audio, ext, cname):
    j = JOBS[jid]; vid = video_id(url)
    try:
        if end - ss < 1: raise RuntimeError("End must be at least 1 second after Start.")
        j["msg"] = "Waiting for a free slot..."
        with RSEM:
            try: name = render_fast(j, vid, ss, end, fmt, mode, pan, q, speed, audio, ext, cname)
            except Exception:
                j["pct"] = 0; j["msg"] = "Fast path failed, using safe mode..."
                name = render_slow(j, vid, ss, end, fmt, mode, pan, q, speed, audio, ext, cname)
        j.update(file_into_library(os.path.join(OUT, name), name, ext, url, ss, end, fmt, mode, q))
        j.update(pct=1, msg="Done", done=True)
    except Exception as e:
        j["err"] = str(e)


def file_into_library(tmp, name, ext, url, ss, end, fmt, mode, q):
    """Move a finished render to its permanent home and return the job fields for the UI.

    MP4 video goes into clips/<id>/0.mp4 and is recorded in history, so it shows up in the
    Library tab next to the captioned shorts (preview, reveal-in-folder, delete all work).
    MOV / MP3 / M4A go to exports/ and are served as plain downloads.
    """
    size = round(os.path.getsize(tmp) / 1e6, 1)
    if ext == "mp4":
        clip_id = uuid.uuid4().hex
        folder = CLIPS_DIR / clip_id; folder.mkdir(parents=True, exist_ok=True)
        shutil.move(tmp, str(folder / "0.mp4"))
        title = os.path.splitext(name)[0]
        clip = dict(index=0, title=title, start=round(ss, 2), end=round(end, 2), url=f"/clips/{clip_id}/0.mp4", language=None, filename=name)
        try:
            history.add_entry(clip_id=clip_id, source=url, source_type="url", clips=[clip],
                              settings=dict(aspect_ratio="9:16" if fmt == "vertical" else "16:9", fit_mode=("crop" if mode == "fill" else "fit") if fmt == "vertical" else "original",
                                            caption_style="none", num_clips=1, language=None, origin="moment-finder", quality=q))
        except Exception: pass
        return dict(file=name, size=size, url=clip["url"], clip_id=clip_id)
    final, i, base = name, 1, os.path.splitext(name)[0]
    while (EXPORTS_DIR / final).exists():
        i += 1; final = f"{base} ({i}).{ext}"
    shutil.move(tmp, str(EXPORTS_DIR / final))
    return dict(file=final, size=size, url="/api/finder/export/" + urllib.parse.quote(final), clip_id=None)


def start(fn, *args):
    jid = uuid.uuid4().hex; JOBS[jid] = {"msg": "Starting..."}
    threading.Thread(target=fn, args=(jid, *args), daemon=True).start()
    return jid


def Y():
    """yt-dlp command prefix. Honours the same cookie env vars as the Studio downloader
    (SPINESLOTH_COOKIES_FILE / SPINESLOTH_COOKIES_BROWSER) so age/sign-in walls are handled."""
    a = [sys.executable, "-m", "yt_dlp"]
    cf = os.environ.get("SPINESLOTH_COOKIES_FILE") or os.environ.get("CLIPFORGE_COOKIES_FILE")
    br = os.environ.get("SPINESLOTH_COOKIES_BROWSER") or os.environ.get("CLIPFORGE_COOKIES_BROWSER")
    if cf and os.path.isfile(cf): a += ["--cookies", cf]
    elif br: a += ["--cookies-from-browser", br.strip().lower()]
    return a


def health():
    return dict(ffmpeg=bool(shutil.which("ffmpeg")), js=bool(shutil.which("deno") or shutil.which("node")), hw=bool(_ENC))


def prune_previews(max_age=2 * 86400):
    for f in glob.glob(os.path.join(CACHE, "p_*.mp4")):
        try:
            if time.time() - os.path.getmtime(f) > max_age: os.remove(f)
        except OSError: pass


def cut_segment(vid, ss, end, dest, q="1080"):
    """Download ONLY [ss, end] of a YouTube video (video + audio) into ``dest`` (mp4, AAC audio).

    This is what makes Moment Finder -> Captioned short fast: nothing but the chosen range is
    fetched, instead of the whole video. Falls back to a yt-dlp section download, and always
    verifies the result really has sound.
    """
    dur, dest = end - ss, str(dest)
    sel = sel_for(q)
    try:
        fm = resolve(vid, sel)
        run(["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y"] + ff_inputs(fm, ss) + ff_maps(fm) +
            ["-t", f"{dur:.3f}", "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p",
             "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", dest], timeout=1800)
    except Exception:
        RES.pop((vid, sel), None)
        stem = f"seg_{vid}_{int(ss * 1000)}_{int(end * 1000)}"
        rm(os.path.join(CACHE, stem + "*"))
        run(Y() + ["--no-playlist", "--download-sections", f"*{ss:.2f}-{end:.2f}", "--force-keyframes-at-cuts", "-f", sel,
                   "--merge-output-format", "mp4", "--retries", "10", "--fragment-retries", "10", "--concurrent-fragments", "8",
                   "-o", os.path.join(CACHE, stem + ".%(ext)s"), "https://www.youtube.com/watch?v=" + vid], timeout=3600)
        got = media.repair_download(Path(CACHE), stem)
        if not got: raise RuntimeError("Could not download that part of the video.")
        shutil.move(str(got), dest); rm(os.path.join(CACHE, stem + "*"))
    if not media.probe(dest)["has_audio"]:
        raise RuntimeError("The downloaded part has no audio. Update yt-dlp (pip install -U yt-dlp) and retry.")
    return dest
