"""HTTP routes for the Moment Finder (all under /api/finder).

Thin wrappers over :mod:`app.finder`. Endpoints are plain ``def`` so FastAPI runs them in its
threadpool - yt-dlp / ffmpeg calls here are blocking and must not stall the event loop.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict

from fastapi import APIRouter, Body, Query
from fastapi.responses import FileResponse, JSONResponse

from . import finder as fd
from .paths import EXPORTS_DIR

router = APIRouter(prefix="/api/finder", tags=["moment-finder"])


def _err(msg: str, code: int = 400) -> JSONResponse:
    return JSONResponse({"error": msg}, status_code=code)


@router.get("/health")
def health() -> dict:
    return fd.health()


@router.post("/analyze")
def analyze(d: Dict[str, Any] = Body(default={})) -> Any:
    if not fd.video_id(d.get("url")):
        return _err("That is not a YouTube video link.")
    opts = {k: bool(d.get(k, True)) for k in ("chat", "cmt", "tx", "aud")}
    return {"job": fd.start(fd.analyze_job, d["url"], opts, bool(d.get("force")))}


@router.get("/rank")
def rank(
    vid: str = Query(""),
    length: float = Query(60),
    count: int = Query(20),
    mode: str = Query("smart"),
) -> Any:
    s = fd.load_sig(vid)
    if not s:
        return _err("Unknown video. Analyze it first.", 404)
    length = max(5, min(int(length), max(5, s["duration"])))
    count = max(1, min(int(count), 60))
    mode = "fixed" if mode == "fixed" else "smart"
    moments, tl, st = fd.rank(s, length, count, mode)
    return {"moments": moments, "timeline": tl, "stats": st, "title": s["title"], "duration": s["duration"], "length": length}


@router.get("/search")
def search(vid: str = Query(""), q: str = Query("")) -> Any:
    s = fd.load_sig(vid)
    q = (q or "").strip().lower()
    if not s or not q:
        return _err("Nothing to search")
    if not s.get("segs"):
        return _err("No transcript for this video (turn on Transcript and re-scan).", 404)
    return {"hits": [{"t": int(g[0]), "text": g[2][:160]} for g in s["segs"] if q in g[2].lower()][:40]}


@router.post("/preview")
def preview(d: Dict[str, Any] = Body(default={})) -> Any:
    vid = fd.video_id(d.get("url"))
    if not vid:
        return _err("Bad request")
    s = fd.load_sig(vid)
    dur = s["duration"] if s else 0
    prio = bool(d.get("prio"))
    for r in (d.get("ranges") or [])[:20]:
        try:
            key, base, stop = fd.pvinfo(vid, float(r[0]), float(r[1]), dur)
        except (ValueError, TypeError, IndexError):
            continue
        if os.path.exists(os.path.join(fd.CACHE, key)):
            fd.PREV[key] = "ok"
            continue
        st = fd.PREV.get(key)
        if st is None or (prio and st in ("queued", "fail")):
            fd.PREV[key] = "queued"
            (fd.PRIOPOOL if prio else fd.PREVPOOL).submit(fd.make_preview, vid, key, base, stop)
    return {"ok": True}


@router.get("/pv")
def pv(keys: str = Query("")) -> dict:
    ks = [k for k in keys.split(",") if re.fullmatch(r"p_[\w-]{11}_\d+_\d+\.mp4", k)]
    return {
        "ready": [k for k in ks if fd.PREV.get(k) == "ok" or os.path.exists(os.path.join(fd.CACHE, k))],
        "failed": [k for k in ks if fd.PREV.get(k) == "fail"],
    }


@router.post("/render")
def render(d: Dict[str, Any] = Body(default={})) -> Any:
    if not fd.video_id(d.get("url")) or d.get("fmt") not in ("horizontal", "vertical") or d.get("mode") not in ("fill", "fit"):
        return _err("Bad request")
    try:
        ss, end, pan = float(d["ss"]), float(d["end"]), min(1, max(0, float(d.get("pan", 0.5))))
    except (KeyError, ValueError, TypeError):
        return _err("Bad times")
    ext = d.get("ext") if d.get("ext") in fd.EXTS else ("mp3" if d.get("audio") else "mp4")
    job = fd.start(
        fd.render_job, d["url"], ss, end, d["fmt"], d["mode"], pan, str(d.get("q", "1080")),
        str(d.get("speed", "fast")), ext in ("mp3", "m4a"), ext, str(d.get("name") or ""),
    )
    return {"job": job}


@router.get("/info")
def info(vid: str = Query("")) -> Any:
    if not re.fullmatch(r"[\w-]{11}", vid):
        return _err("Bad id")
    s = fd.load_sig(vid)
    if s:
        return {"duration": s["duration"], "title": s["title"]}
    try:
        i = json.loads(fd.run(fd.Y() + ["-J", "--no-warnings", "--no-playlist", "https://www.youtube.com/watch?v=" + vid], timeout=180))
        return {"duration": int(i.get("duration") or 0), "title": i.get("title", "")}
    except Exception as e:  # noqa: BLE001
        return _err(str(e), 500)


@router.get("/fps")
def fps(vid: str = Query(""), q: str = Query("1080")) -> Any:
    if not re.fullmatch(r"[\w-]{11}", vid):
        return _err("Bad id")
    try:
        v = next((f for f in fd.resolve(vid, fd.sel_for(q)) if f["v"]), None)
        return {"fps": int(round(v["fps"])) if v and v.get("fps") else None}
    except Exception:  # noqa: BLE001
        return {"fps": None}


@router.get("/job/{jid}")
def job(jid: str) -> dict:
    return fd.JOBS.get(jid, {"err": "Unknown job (server restarted?)"})


@router.get("/export/{name}")
def export(name: str) -> Any:
    """Download a non-MP4 export (MOV / MP3 / M4A) as an attachment."""
    path = (EXPORTS_DIR / os.path.basename(name)).resolve()
    if EXPORTS_DIR.resolve() not in path.parents or not path.is_file():
        return _err("File not found.", 404)
    return FileResponse(str(path), filename=path.name)
